# Github

## 1.Repository-库

进入主页，创建库。

![1704647331933](image/README/1704647331933.png)

- 文档介绍
- 隐私设置
- 是否自动添加解释文件
- ignore文件的格式

![1704647546785](image/README/1704647546785.png)
